function fig2octobre17
m = 0;
x = linspace(0,1,50)

t = linspace(0,100,100)



sol = pdepe(m,@pdex4pde,@pdex4ic,@pdex4bc,x,t);
  u1 = sol(100,:,1);
   u2 = sol(100,:,2);
   u3 = sol(100,:,3);
%  u1 = sol(:,:,1);
%   u2 = sol(:,:,2);
%   u3 = sol(:,:,3);
 
%max(u1)
%min(u1)

%  plot(u1)
%  hold on
%   plot(u2)
%   hold on
% 
% plot(u3)

figure

plot(x,u1,'r:','LineWidth',2)
ax = gca;
ax.FontSize = 12;
hold on
plot(x,u2,'b-','LineWidth',2)
ax = gca;
ax.FontSize = 12;
hold on
plot(x,u3,'k--','LineWidth',2)
ax = gca;
ax.FontSize = 12;
xlabel('Distance x','FontSize',18)
ylabel('bacterial density','FontSize',18)
legend('Substrat','Isolated','attached')
title('(j)')

grid on 
 
% % 
function [c,f,s] = pdex4pde(x,t,u,DuDx)
c = [1; 1;1]; 

f = [1; 0.2; 1] .* DuDx;


x = u(1);
y = u(2);
z = u(3);
 F1 =4* x/(1+x);
  %F1 =3* x/(1+x+x* x);
  F2=5* x/(1+x);
   F3= (y+z)*z;
  F4= (1+z)*(y+z);

  A=10
  B=10
  FF1=-F1*y-F2*z
  FF2=F1*y-A*F3*y+F4*z
  FF3=F2*z+F3*y-B*F4*z
  
s = [FF1;FF2;FF3]-DuDx; 
% --------------------------------------------------------------
function u0 = pdex4ic(x);
u0 = [1;0.1;0.1]; 
% --------------------------------------------------------------
function [pl,ql,pr,qr] = pdex4bc(xl,ul,xr,ur,t)
pr = [0; 0;0]; 
qr = [1; 1;1]; 
pl = [ul(1)-1; ul(2);ul(3)]; 
ql = [-1; -1;-1]